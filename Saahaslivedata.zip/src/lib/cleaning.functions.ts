import { createServerFn } from "@tanstack/react-start";

export interface LogLine {
  source: "system" | "python" | "error";
  message: string;
  timestamp: string;
}

export interface CleaningResult {
  ok: boolean;
  error?: string;
  logs: LogLine[];
  salesCleaned: any[];
  purchaseCleaned: any[];
  stats: {
    salesRawCount: number;
    salesCleanedCount: number;
    salesImputedBalances: number;
    purchaseRawCount: number;
    purchaseCleanedCount: number;
    purchaseImputedBalances: number;
  };
}

// Client-side/portable clean function (TypeScript)
export function cleanDataTS(type: "sales" | "purchase", data: any[]): { cleaned: any[]; imputedCount: number } {
  let imputedCount = 0;
  
  const cleaned = data.map((row) => {
    const newRow = { ...row };
    
    // 1. Column header mapping & normalization
    const normalizedKeys: Record<string, any> = {};
    for (const key of Object.keys(newRow)) {
      const normKey = key.trim().toLowerCase().replace(/\s+/g, "_").replace("#", "num");
      normalizedKeys[normKey] = newRow[key];
    }

    // 2. Identify and standardise fields
    // Map customer/vendor names
    let partyName = "";
    if (type === "sales") {
      partyName = normalizedKeys.customer_name || normalizedKeys.customer || normalizedKeys.client || normalizedKeys.party || "";
    } else {
      partyName = normalizedKeys.vendor_name || normalizedKeys.vendor || normalizedKeys.supplier || normalizedKeys.party || "";
    }
    
    let invoiceNum = normalizedKeys.invoice_number || normalizedKeys.invoice_no || normalizedKeys.invoice_num || 
                     normalizedKeys.bill_number || normalizedKeys.bill_no || normalizedKeys.bill_num || 
                     normalizedKeys.number || normalizedKeys.ref || "";

    let date = normalizedKeys.date || normalizedKeys.invoice_date || normalizedKeys.bill_date || "";
    let total = normalizedKeys.total || normalizedKeys.total_amount || normalizedKeys.amount || 0;
    let balance = normalizedKeys.balance || normalizedKeys.balance_due || normalizedKeys.outstanding || null;
    let status = normalizedKeys.status || normalizedKeys.invoice_status || "";

    // 3. Imputation Strategy
    // Convert values
    const numTotal = Number(total) || 0;
    let numBalance = balance !== null && balance !== "" ? Number(balance) : null;
    
    const strStatus = String(status).trim().toLowerCase();
    
    // Impute balance based on status
    if (strStatus === "paid") {
      if (numBalance !== 0) {
        numBalance = 0;
        imputedCount++;
      }
    } else if (numBalance === null || isNaN(numBalance)) {
      numBalance = numTotal; // If balance is missing, assume outstanding total
      imputedCount++;
    }

    // Standardize dates
    let dateStr = "";
    if (date) {
      try {
        const parsedDate = new Date(date);
        if (!isNaN(parsedDate.getTime())) {
          dateStr = parsedDate.toISOString().slice(0, 10);
        } else {
          dateStr = new Date().toISOString().slice(0, 10);
        }
      } catch {
        dateStr = new Date().toISOString().slice(0, 10);
      }
    } else {
      dateStr = new Date().toISOString().slice(0, 10);
      imputedCount++;
    }

    // Reconstruct normalized row
    return {
      invoice_number: String(invoiceNum || "INV-TEMP-" + Math.floor(Math.random() * 100000)),
      party_name: String(partyName || (type === "sales" ? "Unknown Customer" : "Unknown Vendor")),
      date: dateStr,
      total: numTotal,
      balance: numBalance ?? 0,
      status: strStatus || "open",
    };
  });

  return { cleaned, imputedCount };
}

// Server function to execute python script locally on the server
export const runPythonCleaning = createServerFn({ method: "POST" })
  .inputValidator(
    (data: {
      salesCsv: string;
      purchaseCsv: string;
      salesScript: string;
      purchaseScript: string;
    } | undefined) => data!
  )
  .handler(async ({ data }): Promise<CleaningResult> => {
    const logs: LogLine[] = [];
    const addLog = (source: "system" | "python" | "error", message: string) => {
      logs.push({
        source,
        message,
        timestamp: new Date().toLocaleTimeString(),
      });
    };

    addLog("system", "Starting Python data cleaning pipeline on host system...");

    try {
      // Dynamic imports for Node dependencies, ensuring Cloudflare compilation safety
      const fs = typeof window === "undefined" ? await import("fs/promises") : null;
      const path = typeof window === "undefined" ? await import("path") : null;
      const cp = typeof window === "undefined" ? await import("child_process") : null;
      const os = typeof window === "undefined" ? await import("os") : null;

      if (!fs || !path || !cp || !os) {
        throw new Error("Local filesystem and process execution modules are not available in this environment.");
      }

      // 1. Setup temporary workspace directory inside the project
      const tempDir = path.join(process.cwd(), "scratch_cleaning");
      addLog("system", `Creating workspace at: ${tempDir}`);
      
      await fs.mkdir(tempDir, { recursive: true });

      // 2. Write CSV data inputs
      const salesRawPath = path.join(tempDir, "raw_sales.csv");
      const purchaseRawPath = path.join(tempDir, "raw_purchase.csv");
      await fs.writeFile(salesRawPath, data.salesCsv, "utf-8");
      await fs.writeFile(purchaseRawPath, data.purchaseCsv, "utf-8");
      
      addLog("system", "Wrote raw data inputs: raw_sales.csv & raw_purchase.csv");

      // 3. Write python scripts
      const salesScriptPath = path.join(tempDir, "clean_sales.py");
      const purchaseScriptPath = path.join(tempDir, "clean_purchase.py");
      await fs.writeFile(salesScriptPath, data.salesScript, "utf-8");
      await fs.writeFile(purchaseScriptPath, data.purchaseScript, "utf-8");
      
      addLog("system", "Wrote Python cleaning scripts: clean_sales.py & clean_purchase.py");

      const execPythonFile = (scriptPath: string): Promise<string> => {
        return new Promise((resolve, reject) => {
          // Check if there is a local virtual environment Python first
          const localVenvPy = path.join(process.cwd(), ".venv", "Scripts", "python.exe");
          const venvExists = require("fs").existsSync(localVenvPy);
          const cmd = venvExists ? `"${localVenvPy}"` : "python";
          
          addLog("system", `Executing Python command: ${cmd} "${scriptPath}"`);
          
          cp.exec(`${cmd} "${scriptPath}"`, { cwd: tempDir }, (error: any, stdout: string, stderr: string) => {
            if (stdout) {
              stdout.split("\n").forEach((line) => {
                if (line.trim()) addLog("python", line.trim());
              });
            }
            if (stderr) {
              stderr.split("\n").forEach((line) => {
                if (line.trim()) addLog("error", line.trim());
              });
            }
            if (error) {
              reject(new Error(`Python script failed with code ${error.code}: ${error.message}`));
            } else {
              resolve(stdout);
            }
          });
        });
      };

      // 4. Run Python scripts
      addLog("system", "Running Sales cleaning script...");
      await execPythonFile(salesScriptPath);
      
      addLog("system", "Running Purchase cleaning script...");
      await execPythonFile(purchaseScriptPath);

      // 5. Read clean CSV outputs
      const salesCleanPath = path.join(tempDir, "sales_clean.csv");
      const purchaseCleanPath = path.join(tempDir, "purchase_clean.csv");
      
      const salesCleanExists = require("fs").existsSync(salesCleanPath);
      const purchaseCleanExists = require("fs").existsSync(purchaseCleanPath);

      if (!salesCleanExists || !purchaseCleanExists) {
        throw new Error(
          `Imputed output files were not generated. Sales output: ${
            salesCleanExists ? "Found" : "MISSING"
          }, Purchase output: ${purchaseCleanExists ? "Found" : "MISSING"}`
        );
      }

      const salesCleanedContent = await fs.readFile(salesCleanPath, "utf-8");
      const purchaseCleanedContent = await fs.readFile(purchaseCleanPath, "utf-8");

      // Simple CSV parser to convert back to JSON array of objects
      const parseCSV = (csv: string): any[] => {
        const lines = csv.split("\n").map(l => l.trim()).filter(Boolean);
        if (lines.length === 0) return [];
        
        // Handle headers
        const headers = lines[0].split(",").map(h => h.replace(/^["']|["']$/g, "").trim());
        
        return lines.slice(1).map(line => {
          // Simple regex to parse CSV taking care of quotes
          const matches = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || line.split(",");
          const obj: any = {};
          headers.forEach((header, index) => {
            let val = matches[index] || "";
            val = val.replace(/^["']|["']$/g, "").trim();
            
            // Cast numeric strings if possible
            if (!isNaN(val as any) && val !== "") {
              obj[header] = Number(val);
            } else {
              obj[header] = val;
            }
          });
          return obj;
        });
      };

      const salesCleaned = parseCSV(salesCleanedContent);
      const purchaseCleaned = parseCSV(purchaseCleanedContent);

      addLog("system", `Successfully read cleaned data: ${salesCleaned.length} sales records, ${purchaseCleaned.length} purchase records.`);

      // Clean up temp workspace files
      try {
        await fs.rm(tempDir, { recursive: true, force: true });
        addLog("system", "Cleaned up temporary workspace directory.");
      } catch (rmErr) {
        addLog("system", `Warning during cleanup: ${String(rmErr)}`);
      }

      return {
        ok: true,
        logs,
        salesCleaned,
        purchaseCleaned,
        stats: {
          salesRawCount: data.salesCsv.split("\n").filter(Boolean).length - 1,
          salesCleanedCount: salesCleaned.length,
          salesImputedBalances: 0, // Set to 0 since python handled it internally
          purchaseRawCount: data.purchaseCsv.split("\n").filter(Boolean).length - 1,
          purchaseCleanedCount: purchaseCleaned.length,
          purchaseImputedBalances: 0,
        }
      };
    } catch (e: any) {
      addLog("error", `Exception occurred: ${e.message || String(e)}`);
      return {
        ok: false,
        error: e.message || String(e),
        logs,
        salesCleaned: [],
        purchaseCleaned: [],
        stats: {
          salesRawCount: 0,
          salesCleanedCount: 0,
          salesImputedBalances: 0,
          purchaseRawCount: 0,
          purchaseCleanedCount: 0,
          purchaseImputedBalances: 0,
        }
      };
    }
  });
