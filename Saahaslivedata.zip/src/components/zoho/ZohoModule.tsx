import { useState } from "react";
import {
  Cable,
  Sparkles,
  CheckCircle2,
  Loader2,
  Database,
  ShieldCheck,
  Wand2,
  RefreshCw,
  AlertTriangle,
  Download,
  Upload,
  Play,
  Terminal,
  ArrowRight,
  FileText,
  Check,
  FileSpreadsheet,
  Code,
  Copy,
  X,
} from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { MetricCard } from "@/components/data/MetricCard";
import { Logo } from "@/components/brand/Logo";
import * as XLSX from "xlsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { runPythonCleaning, cleanDataTS, type LogLine } from "@/lib/cleaning.functions";

import { syncZohoBooks, type SyncResult } from "@/lib/zoho.functions";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell as PieCell,
  Legend,
} from "recharts";

const STEPS = [
  { label: "Authenticating via Zoho OAuth 2.0…", icon: ShieldCheck },
  { label: "Pulling live invoice ledger from Zoho Books…", icon: Database },
  { label: "Aggregating KPIs & imputing balances…", icon: Wand2 },
];

type Phase = "idle" | "syncing" | "done" | "error";

const PIE_COLORS = [
  "oklch(0.696 0.17 162.48)",
  "oklch(0.609 0.155 163.225)",
  "oklch(0.279 0.041 260.031)",
  "oklch(0.554 0.046 257.417)",
  "oklch(0.75 0.14 80)",
  "oklch(0.65 0.15 25)",
];

function formatMoney(n: number, currency = "INR") {
  try {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(n);
  } catch {
    return `${currency} ${Math.round(n).toLocaleString("en-IN")}`;
  }
}

function exportInvoicesToCSV(invoices: SyncResult["allInvoices"], currency: string) {
  const headers = ["Invoice ID", "Invoice Number", "Customer Name", "Status", "Date", "Due Date", "Total", "Balance", "Currency"];
  const rows = invoices.map((inv) => [
    inv.invoice_id ?? "",
    inv.invoice_number ?? "",
    inv.customer_name ?? "",
    inv.status ?? "",
    inv.date ?? "",
    inv.due_date ?? "",
    String(inv.total ?? 0),
    String(inv.balance ?? 0),
    inv.currency_code ?? currency,
  ]);
  const csv = [headers.join(","), ...rows.map((r) => r.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `zoho-invoices-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

const DEFAULT_SALES_PY = `import pandas as pd
import numpy as np
import os

# Read the raw input
if os.path.exists("raw_sales.csv"):
    df = pd.read_csv("raw_sales.csv")
    print(f"Loaded {len(df)} raw sales rows.")
    
    # Step 1: Normalize column names (lowercase & remove spaces)
    df.columns = [c.strip().lower().replace(" ", "_").replace("#", "num") for c in df.columns]
    
    # Step 2: Handle missing values and type casting
    df['total'] = pd.to_numeric(df.get('total', 0), errors='coerce').fillna(0)
    
    if 'balance' in df.columns:
        df['balance'] = pd.to_numeric(df['balance'], errors='coerce')
        # Imputation strategy: if status is paid, balance is 0
        if 'status' in df.columns:
            df.loc[df['status'].str.lower() == 'paid', 'balance'] = 0
        # Imputation strategy: fill missing balances with total
        df['balance'] = df['balance'].fillna(df['total'])
        
    # Step 3: Date standardisation
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        df['date'] = df['date'].dt.strftime('%Y-%m-%d')
        df['date'] = df['date'].fillna(pd.Timestamp.now().strftime('%Y-%m-%d'))
        
    # Step 4: Fill missing text fields
    if 'customer_name' in df.columns:
        df['customer_name'] = df['customer_name'].fillna("Unknown Customer")
        
    # Step 5: Export to clean output
    df.to_csv("sales_clean.csv", index=False)
    print(f"Data imputation complete: {df['balance'].isna().sum()} nulls remaining.")
    print("Cleaned sales data saved to sales_clean.csv successfully.")
else:
    print("raw_sales.csv not found!")
`;

const DEFAULT_PURCHASE_PY = `import pandas as pd
import numpy as np
import os

if os.path.exists("raw_purchase.csv"):
    df = pd.read_csv("raw_purchase.csv")
    print(f"Loaded {len(df)} raw purchase rows.")
    
    # Step 1: Normalize column names
    df.columns = [c.strip().lower().replace(" ", "_").replace("#", "num") for c in df.columns]
    
    # Step 2: Handle missing values and type casting
    df['total'] = pd.to_numeric(df.get('total', 0), errors='coerce').fillna(0)
    
    if 'balance' in df.columns:
        df['balance'] = pd.to_numeric(df['balance'], errors='coerce')
        # Imputation strategy: if status is paid, balance is 0
        if 'status' in df.columns:
            df.loc[df['status'].str.lower() == 'paid', 'balance'] = 0
        # Imputation: fill empty balance with total
        df['balance'] = df['balance'].fillna(df['total'])
        
    # Step 3: Date standardisation
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        df['date'] = df['date'].dt.strftime('%Y-%m-%d')
        df['date'] = df['date'].fillna(pd.Timestamp.now().strftime('%Y-%m-%d'))
        
    # Step 4: Fill missing vendor names
    if 'vendor_name' in df.columns:
        df['vendor_name'] = df['vendor_name'].fillna("Unknown Vendor")
        
    # Step 5: Save output
    df.to_csv("purchase_clean.csv", index=False)
    print("Cleaned purchase data saved to purchase_clean.csv successfully.")
else:
    print("raw_purchase.csv not found!")
`;

export function ZohoModule() {
  const sync = useServerFn(syncZohoBooks);
  const pythonRun = useServerFn(runPythonCleaning);
  const [phase, setPhase] = useState<Phase>("idle");
  const [step, setStep] = useState(0);
  const [data, setData] = useState<SyncResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Default to current fiscal year (Apr 1 → today)
  const today = new Date();
  const fyStartYear = today.getMonth() >= 3 ? today.getFullYear() : today.getFullYear() - 1;
  const defaultFrom = `${fyStartYear}-04-01`;
  const defaultTo = today.toISOString().slice(0, 10);
  const [fromDate, setFromDate] = useState<string>(defaultFrom);
  const [toDate, setToDate] = useState<string>(defaultTo);

  // Tab navigation state
  const [activeTab, setActiveTab] = useState("live");

  // Imputation module states
  const [salesFile, setSalesFile] = useState<File | null>(null);
  const [purchaseFile, setPurchaseFile] = useState<File | null>(null);
  const [salesRawData, setSalesRawData] = useState<any[] | null>(null);
  const [purchaseRawData, setPurchaseRawData] = useState<any[] | null>(null);
  const [salesCsvString, setSalesCsvString] = useState<string>("");
  const [purchaseCsvString, setPurchaseCsvString] = useState<string>("");
  
  const [engine, setEngine] = useState<"js" | "python">("js");
  const [salesScriptText, setSalesScriptText] = useState(DEFAULT_SALES_PY);
  const [purchaseScriptText, setPurchaseScriptText] = useState(DEFAULT_PURCHASE_PY);
  
  const [pipelineLogs, setPipelineLogs] = useState<LogLine[]>([]);
  const [pipelinePhase, setPipelinePhase] = useState<"idle" | "running" | "done" | "error">("idle");
  const [pipelineStats, setPipelineStats] = useState({
    salesRawCount: 0,
    salesCleanedCount: 0,
    salesImputedBalances: 0,
    purchaseRawCount: 0,
    purchaseCleanedCount: 0,
    purchaseImputedBalances: 0,
  });
  
  const [cleanedSales, setCleanedSales] = useState<any[] | null>(null);
  const [cleanedPurchase, setCleanedPurchase] = useState<any[] | null>(null);
  const [previewTab, setPreviewTab] = useState<"sales" | "purchase">("sales");
  const [editorTab, setEditorTab] = useState<"sales" | "purchase">("sales");

  const handleFileUpload = (file: File, type: "sales" | "purchase") => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const arrayBuffer = e.target?.result;
      if (!arrayBuffer) return;
      
      try {
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const json = XLSX.utils.sheet_to_json<any>(worksheet, { defval: "" });
        const csv = XLSX.utils.sheet_to_csv(worksheet);
        
        if (type === "sales") {
          setSalesFile(file);
          setSalesRawData(json);
          setSalesCsvString(csv);
        } else {
          setPurchaseFile(file);
          setPurchaseRawData(json);
          setPurchaseCsvString(csv);
        }
      } catch (err) {
        console.error("Error reading file:", err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleScriptUpload = (file: File, type: "sales" | "purchase") => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (type === "sales") {
        setSalesScriptText(text);
      } else {
        setPurchaseScriptText(text);
      }
    };
    reader.readAsText(file);
  };

  const runTSPipeline = () => {
    setPipelineLogs([]);
    setPipelinePhase("running");
    
    const logs: LogLine[] = [];
    const addLog = (source: "system" | "python" | "error", message: string) => {
      const line = { source, message, timestamp: new Date().toLocaleTimeString() };
      logs.push(line);
      setPipelineLogs([...logs]);
    };
    
    setTimeout(() => {
      addLog("system", "Initializing in-browser Data Imputation Engine (TypeScript)...");
    }, 100);

    setTimeout(() => {
      if (!salesRawData && !purchaseRawData) {
        addLog("error", "No raw Zoho files uploaded. Please drop Sales or Purchase spreadsheet files.");
        setPipelinePhase("error");
        return;
      }
      
      let finalSales: any[] = [];
      let finalPurchase: any[] = [];
      let salesImputedCount = 0;
      let purchaseImputedCount = 0;
      
      if (salesRawData) {
        addLog("system", `Profiling raw Sales dataset: found ${salesRawData.length} records.`);
        addLog("system", "Step 1: Normalizing column schemas & lowercasing identifiers...");
        addLog("system", "Step 2: Checking date fields & applying local timestamp fallbacks...");
        addLog("system", "Step 3: Executing balance imputation strategy (Paid -> 0, Missing -> Total)...");
        const { cleaned, imputedCount } = cleanDataTS("sales", salesRawData);
        finalSales = cleaned;
        salesImputedCount = imputedCount;
        addLog("system", `Sales clean completed. Imputed outstanding balances for ${imputedCount} invoices.`);
      }
      
      if (purchaseRawData) {
        addLog("system", `Profiling raw Purchase dataset: found ${purchaseRawData.length} records.`);
        addLog("system", "Step 1: Standardizing bill number & supplier names headers...");
        addLog("system", "Step 2: Aligning transactional dates...");
        addLog("system", "Step 3: Applying vendor balance imputations...");
        const { cleaned, imputedCount } = cleanDataTS("purchase", purchaseRawData);
        finalPurchase = cleaned;
        purchaseImputedCount = imputedCount;
        addLog("system", `Purchase clean completed. Imputed outstanding balances for ${imputedCount} bills.`);
      }
      
      setCleanedSales(finalSales);
      setCleanedPurchase(finalPurchase);
      setPipelineStats({
        salesRawCount: salesRawData?.length ?? 0,
        salesCleanedCount: finalSales.length,
        salesImputedBalances: salesImputedCount,
        purchaseRawCount: purchaseRawData?.length ?? 0,
        purchaseCleanedCount: finalPurchase.length,
        purchaseImputedBalances: purchaseImputedCount,
      });
      
      addLog("system", "Pipeline compilation successful. Cleans completed with zero exceptions.");
      setPipelinePhase("done");
    }, 1000);
  };

  const runPythonPipeline = async () => {
    setPipelineLogs([]);
    setPipelinePhase("running");
    
    const logs: LogLine[] = [];
    const addLog = (source: "system" | "python" | "error", message: string) => {
      logs.push({ source, message, timestamp: new Date().toLocaleTimeString() });
      setPipelineLogs([...logs]);
    };
    
    addLog("system", "Connecting to local server Python runtime (v3.13)...");
    
    if (!salesCsvString && !purchaseCsvString) {
      addLog("error", "No data uploaded. Please upload Sales or Purchase files.");
      setPipelinePhase("error");
      return;
    }
    
    try {
      const result = await pythonRun({
        data: {
          salesCsv: salesCsvString || "invoice_number,customer_name,date,total,balance,status\n",
          purchaseCsv: purchaseCsvString || "bill_number,vendor_name,date,total,balance,status\n",
          salesScript: salesScriptText,
          purchaseScript: purchaseScriptText,
        }
      });
      
      setPipelineLogs(result.logs);
      
      if (!result.ok) {
        addLog("error", result.error ?? "Python script execution failed.");
        setPipelinePhase("error");
        return;
      }
      
      setCleanedSales(result.salesCleaned);
      setCleanedPurchase(result.purchaseCleaned);
      setPipelineStats(result.stats);
      setPipelinePhase("done");
    } catch (e: any) {
      addLog("error", e.message || String(e));
      setPipelinePhase("error");
    }
  };

  const downloadCleanedData = (type: "sales" | "purchase", format: "csv" | "xlsx") => {
    const data = type === "sales" ? cleanedSales : cleanedPurchase;
    if (!data || data.length === 0) return;
    
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Cleaned Data");
    
    if (format === "xlsx") {
      XLSX.writeFile(wb, `${type}_cleaned_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else {
      const csv = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${type}_cleaned_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  async function runSync() {
    setPhase("syncing");
    setError(null);
    setStep(0);

    const t1 = setTimeout(() => setStep(1), 700);
    const t2 = setTimeout(() => setStep(2), 1600);

    try {
      const result = await sync({ data: { fromDate, toDate } });
      clearTimeout(t1);
      clearTimeout(t2);
      setStep(3);
      if (!result.ok) {
        setError(result.error ?? "Unknown error from Zoho Books");
        setPhase("error");
        return;
      }
      setData(result);
      setPhase("done");
    } catch (e) {
      clearTimeout(t1);
      clearTimeout(t2);
      setError(e instanceof Error ? e.message : String(e));
      setPhase("error");
    }
  }

  function applyPreset(preset: "this-month" | "last-month" | "fy" | "last-fy" | "ytd") {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (preset === "this-month") {
      const s = new Date(now.getFullYear(), now.getMonth(), 1);
      setFromDate(ymd(s));
      setToDate(ymd(now));
    } else if (preset === "last-month") {
      const s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const e = new Date(now.getFullYear(), now.getMonth(), 0);
      setFromDate(ymd(s));
      setToDate(ymd(e));
    } else if (preset === "fy") {
      const y = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
      setFromDate(`${y}-04-01`);
      setToDate(ymd(now));
    } else if (preset === "last-fy") {
      const y = now.getMonth() >= 3 ? now.getFullYear() - 1 : now.getFullYear() - 2;
      setFromDate(`${y}-04-01`);
      setToDate(`${y + 1}-03-31`);
    } else if (preset === "ytd") {
      setFromDate(`${now.getFullYear()}-01-01`);
      setToDate(ymd(now));
    }
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-3">
          <Logo size={44} />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Zoho Live Analytics</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Real-time invoice ledger sync from Zoho Books via OAuth 2.0.
            </p>
          </div>
        </div>

        {activeTab === "live" && (
          <Button
            onClick={runSync}
            disabled={phase === "syncing"}
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            {phase === "syncing" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : phase === "done" ? (
              <RefreshCw className="h-4 w-4" />
            ) : (
              <Cable className="h-4 w-4" />
            )}
            {phase === "syncing"
              ? "Syncing…"
              : phase === "done"
                ? "Re-sync Zoho Books"
                : "Sync Live Zoho Books Data"}
          </Button>
        )}
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-secondary/60 p-1 border border-border/40 rounded-xl">
          <TabsTrigger value="live" className="gap-2 text-xs font-semibold">
            <RefreshCw className="h-3.5 w-3.5" />
            Live Sync &amp; Analytics
          </TabsTrigger>
          <TabsTrigger value="cleaning" className="gap-2 text-xs font-semibold">
            <Wand2 className="h-3.5 w-3.5" />
            Data Cleaning &amp; Imputation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="live" className="space-y-6">
          <div className="rounded-2xl border border-border bg-card p-4 shadow-card">
            <div className="flex flex-wrap items-end gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  From date
                </label>
                <input
                  type="date"
                  value={fromDate}
                  max={toDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  To date
                </label>
                <input
                  type="date"
                  value={toDate}
                  min={fromDate}
                  max={defaultTo}
                  onChange={(e) => setToDate(e.target.value)}
                  className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {[
                  { id: "this-month" as const, label: "This Month" },
                  { id: "last-month" as const, label: "Last Month" },
                  { id: "ytd" as const, label: "YTD" },
                  { id: "fy" as const, label: "FY 2026-27" },
                  { id: "last-fy" as const, label: "Last FY" },
                ].map((p) => (
                  <button
                    key={p.id}
                    onClick={() => applyPreset(p.id)}
                    className="rounded-full border border-border bg-secondary/40 px-3 py-1 text-xs font-medium text-foreground transition-colors hover:border-accent/40 hover:bg-accent/5 hover:text-accent-2"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
            <p className="mt-3 text-[11px] text-muted-foreground">
              Pulls invoices with <span className="font-mono">date</span> between the selected range from Zoho Books.
            </p>
          </div>

          {phase === "idle" && <EmptyState />}
          {phase === "syncing" && <PipelineSteps step={step} />}
          {phase === "error" && (
            <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5 shadow-card mt-6">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-destructive/15 text-destructive">
                  <AlertTriangle className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-semibold text-foreground">Zoho sync failed</h3>
                  <p className="mt-1 text-xs text-muted-foreground break-words">{error}</p>
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    Verify Client ID, Client Secret, Refresh Token and Organization ID are configured.
                  </p>
                </div>
              </div>
            </div>
          )}

          {phase === "done" && data && (
            <div className="space-y-6 animate-fade-in-up mt-6">
              <PipelineSteps step={3} compact />

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <MetricCard
                  label="Total Invoices"
                  value={data.totalCount.toLocaleString("en-IN")}
                  delta={0}
                  hint={`Synced ${new Date(data.fetchedAt).toLocaleTimeString()}`}
                />
                <MetricCard label="Total Invoiced" value={formatMoney(data.totalValue, data.currency)} delta={0} />
                <MetricCard label="Collected" value={formatMoney(data.paid, data.currency)} delta={0} />
                <MetricCard
                  label="Outstanding"
                  value={formatMoney(data.outstanding, data.currency)}
                  delta={0}
                  hint="Open balance across invoices"
                />
              </div>

              <div className="grid gap-5 lg:grid-cols-3">
                <div className="lg:col-span-2 rounded-2xl border border-border bg-card p-5 shadow-card">
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-foreground">Monthly Invoicing</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Total vs collected · last {data.monthly.length} month{data.monthly.length === 1 ? "" : ""}
                    </p>
                  </div>
                  <div className="h-64">
                    {data.monthly.length === 0 ? (
                      <EmptyChart label="No dated invoices returned" />
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data.monthly} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.929 0.013 255.508)" vertical={false} />
                          <XAxis dataKey="m" tick={{ fill: "oklch(0.554 0.046 257.417)", fontSize: 11 }} axisLine={false} tickLine={false} />
                          <YAxis tick={{ fill: "oklch(0.554 0.046 257.417)", fontSize: 11 }} axisLine={false} tickLine={false} />
                          <Tooltip
                            cursor={{ fill: "oklch(0.696 0.17 162.48 / 0.08)" }}
                            contentStyle={{
                              background: "white",
                              border: "1px solid oklch(0.929 0.013 255.508)",
                              borderRadius: 12,
                              fontSize: 12,
                              boxShadow: "0 8px 32px -8px rgb(15 23 42 / 0.15)",
                            }}
                            formatter={(v) => formatMoney(Number(v) || 0, data.currency)}
                          />
                          <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="total" name="Invoiced" fill="oklch(0.279 0.041 260.031)" radius={[6, 6, 0, 0]} maxBarSize={32} />
                          <Bar dataKey="paid" name="Collected" fill="oklch(0.696 0.17 162.48)" radius={[6, 6, 0, 0]} maxBarSize={32} />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

                <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-foreground">Status Breakdown</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Invoice count by status</p>
                  </div>
                  <div className="h-64">
                    {data.statusBreakdown.length === 0 ? (
                      <EmptyChart label="No invoices to break down" />
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={data.statusBreakdown}
                            dataKey="value"
                            nameKey="name"
                            innerRadius={45}
                            outerRadius={75}
                            paddingAngle={3}
                          >
                            {data.statusBreakdown.map((_, i) => (
                              <PieCell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} stroke="white" strokeWidth={2} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={{
                              background: "white",
                              border: "1px solid oklch(0.929 0.013 255.508)",
                              borderRadius: 12,
                              fontSize: 12,
                            }}
                          />
                          <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>
              </div>

              <InvoiceTable
                invoices={data.invoices}
                currency={data.currency}
                onDownload={() => exportInvoicesToCSV(data.allInvoices, data.currency)}
              />
            </div>
          )}
        </TabsContent>

        <TabsContent value="cleaning" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              {/* File upload card */}
              <div className="rounded-2xl border border-border bg-card p-5 shadow-card space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-foreground">Spreadsheet Data Uploads</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Upload raw ledger data extracted from Zoho Live Sync (Sales &amp; Purchase)
                  </p>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  {/* Sales upload */}
                  <div className="rounded-xl border border-dashed border-border bg-secondary/20 p-5 text-center relative group hover:border-accent/40 transition-colors">
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file, "sales");
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <div className="rounded-lg bg-accent/10 p-2 text-accent">
                        <Upload className="h-5 w-5" />
                      </div>
                      <span className="text-xs font-semibold text-foreground">
                        {salesFile ? salesFile.name : "Upload Sales Ledger"}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {salesFile ? `${(salesFile.size / 1024).toFixed(1)} KB` : "Drag and drop CSV or Excel"}
                      </span>
                      {salesRawData && (
                        <span className="inline-flex items-center rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-medium text-accent-2 mt-1">
                          {salesRawData.length} records parsed
                        </span>
                      )}
                    </div>
                    {salesFile && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSalesFile(null);
                          setSalesRawData(null);
                          setSalesCsvString("");
                        }}
                        className="absolute top-2 right-2 rounded-full p-1 bg-secondary hover:bg-destructive/10 text-muted-foreground hover:text-destructive z-25"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>

                  {/* Purchase upload */}
                  <div className="rounded-xl border border-dashed border-border bg-secondary/20 p-5 text-center relative group hover:border-accent/40 transition-colors">
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file, "purchase");
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <div className="rounded-lg bg-accent/10 p-2 text-accent">
                        <Upload className="h-5 w-5" />
                      </div>
                      <span className="text-xs font-semibold text-foreground">
                        {purchaseFile ? purchaseFile.name : "Upload Purchase Ledger"}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {purchaseFile ? `${(purchaseFile.size / 1024).toFixed(1)} KB` : "Drag and drop CSV or Excel"}
                      </span>
                      {purchaseRawData && (
                        <span className="inline-flex items-center rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-medium text-accent-2 mt-1">
                          {purchaseRawData.length} records parsed
                        </span>
                      )}
                    </div>
                    {purchaseFile && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setPurchaseFile(null);
                          setPurchaseRawData(null);
                          setPurchaseCsvString("");
                        }}
                        className="absolute top-2 right-2 rounded-full p-1 bg-secondary hover:bg-destructive/10 text-muted-foreground hover:text-destructive z-25"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button
                    onClick={engine === "js" ? runTSPipeline : runPythonPipeline}
                    disabled={(!salesFile && !purchaseFile) || pipelinePhase === "running"}
                    className="gap-2 bg-accent hover:bg-accent/90 text-white font-semibold"
                  >
                    {pipelinePhase === "running" ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Play className="h-4 w-4" />
                    )}
                    Execute Imputation Pipeline
                  </Button>
                </div>
              </div>

              {/* Console output card */}
              <div className="rounded-2xl border border-border bg-card p-5 shadow-card space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                    <Terminal className="h-4 w-4 text-accent-2" />
                    Pipeline Logs
                  </h3>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono bg-secondary/60 px-2 py-0.5 rounded border border-border">
                    {pipelinePhase || "idle"}
                  </span>
                </div>
                
                <div className="h-48 rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-slate-300 overflow-y-auto space-y-1 select-text border border-border/10">
                  {pipelineLogs.length === 0 ? (
                    <div className="text-slate-500 italic">No activity logs. Select your engine, drop your files, and execute the pipeline to inspect data progress.</div>
                  ) : (
                    pipelineLogs.map((log, index) => {
                      let colorCls = "text-slate-300";
                      if (log.source === "system") colorCls = "text-accent-2";
                      if (log.source === "error") colorCls = "text-destructive";
                      return (
                        <div key={index} className={`flex items-start gap-1 ${colorCls}`}>
                          <span className="text-slate-600 font-normal">[{log.timestamp}]</span>
                          <span className="font-semibold uppercase tracking-wider text-[9px] px-1 rounded bg-secondary/10 border border-secondary/15 mr-1">{log.source}</span>
                          <span className="whitespace-pre-wrap">{log.message}</span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            {/* Sidebar config card */}
            <div className="space-y-6">
              {/* Engine card */}
              <div className="rounded-2xl border border-border bg-card p-5 shadow-card space-y-4">
                <h3 className="text-sm font-semibold text-foreground">Pipeline Engine</h3>
                <div className="grid grid-cols-2 gap-2 p-1 bg-secondary/40 rounded-lg border border-border">
                  <button
                    onClick={() => setEngine("js")}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
                      engine === "js" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    JS/TS Engine
                  </button>
                  <button
                    onClick={() => setEngine("python")}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
                      engine === "python" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    Python Runner
                  </button>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  {engine === "js" 
                    ? "Runs a standard client-side browser normalization of column schemas and outstanding balance imputation (Paid -> 0, Missing -> Total)." 
                    : "Runs custom Python cleaning scripts locally on the server host machine. Standard outputs and traceback logs are captured in the terminal console."}
                </p>
              </div>

              {/* Code editor card */}
              <div className="rounded-2xl border border-border bg-card p-5 shadow-card space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                    <Code className="h-4 w-4 text-accent-2" />
                    Python Script
                  </h3>
                  <div className="flex bg-secondary/40 p-0.5 rounded border border-border text-[10px] font-semibold">
                    <button
                      onClick={() => setEditorTab("sales")}
                      className={`px-2 py-0.5 rounded transition-all ${
                        editorTab === "sales" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
                      }`}
                    >
                      Sales
                    </button>
                    <button
                      onClick={() => setEditorTab("purchase")}
                      className={`px-2 py-0.5 rounded transition-all ${
                        editorTab === "purchase" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
                      }`}
                    >
                      Purchase
                    </button>
                  </div>
                </div>

                <textarea
                  value={editorTab === "sales" ? salesScriptText : purchaseScriptText}
                  onChange={(e) => {
                    if (editorTab === "sales") setSalesScriptText(e.target.value);
                    else setPurchaseScriptText(e.target.value);
                  }}
                  className="w-full h-52 rounded-lg border border-border bg-secondary/20 p-2.5 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-accent-2 leading-relaxed"
                />

                <div className="flex justify-between items-center text-[10px] text-muted-foreground">
                  <span>Editable workspace script</span>
                  <label className="cursor-pointer text-accent-2 hover:underline flex items-center gap-1 font-semibold">
                    <Upload className="h-3 w-3" />
                    Upload .py
                    <input
                      type="file"
                      accept=".py"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleScriptUpload(file, editorTab);
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Stats card */}
              {pipelinePhase === "done" && (
                <div className="rounded-2xl border border-border bg-card p-5 shadow-card space-y-3 animate-fade-in-up">
                  <h3 className="text-sm font-semibold text-foreground">Imputation Summary</h3>
                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between border-b border-border/40 pb-2">
                      <span className="text-muted-foreground">Sales Raw Rows</span>
                      <span className="font-semibold text-foreground">{pipelineStats.salesRawCount}</span>
                    </div>
                    {engine === "js" && (
                      <div className="flex justify-between border-b border-border/40 pb-2">
                        <span className="text-muted-foreground">Sales Imputations</span>
                        <span className="font-semibold text-accent-2">{pipelineStats.salesImputedBalances} rows</span>
                      </div>
                    )}
                    <div className="flex justify-between border-b border-border/40 pb-2">
                      <span className="text-muted-foreground">Purchase Raw Rows</span>
                      <span className="font-semibold text-foreground">{pipelineStats.purchaseRawCount}</span>
                    </div>
                    {engine === "js" && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Purchase Imputations</span>
                        <span className="font-semibold text-accent-2">{pipelineStats.purchaseImputedBalances} rows</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Cleaned preview grid */}
          {pipelinePhase === "done" && (cleanedSales || cleanedPurchase) && (
            <div className="rounded-2xl border border-border bg-card shadow-card overflow-hidden animate-fade-in-up space-y-0">
              <div className="flex flex-wrap items-center justify-between border-b border-border px-5 py-4 gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-foreground">Cleaned Data Preview</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Review and verify normalized outputs before export
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex bg-secondary/40 p-0.5 rounded border border-border text-xs mr-2 font-semibold">
                    <button
                      onClick={() => setPreviewTab("sales")}
                      className={`px-3 py-1 rounded-md transition-all ${
                        previewTab === "sales" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
                      }`}
                    >
                      Sales Clean
                    </button>
                    <button
                      onClick={() => setPreviewTab("purchase")}
                      className={`px-3 py-1 rounded-md transition-all ${
                        previewTab === "purchase" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
                      }`}
                    >
                      Purchase Clean
                    </button>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadCleanedData(previewTab, "csv")}
                    className="gap-1.5 text-xs font-semibold"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download CSV
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadCleanedData(previewTab, "xlsx")}
                    className="gap-1.5 text-xs font-semibold bg-accent/5 hover:bg-accent/10 border-accent/20 text-accent-2"
                  >
                    <FileSpreadsheet className="h-3.5 w-3.5" />
                    Excel Sheet
                  </Button>
                </div>
              </div>

              <div className="overflow-x-auto max-h-72">
                <table className="w-full text-xs">
                  <thead className="bg-secondary/40 text-muted-foreground uppercase tracking-wider sticky top-0 bg-card z-10 border-b border-border">
                    <tr>
                      <th className="px-5 py-2.5 text-left font-medium">Ref / Number</th>
                      <th className="px-5 py-2.5 text-left font-medium">Customer / Vendor</th>
                      <th className="px-5 py-2.5 text-left font-medium">Date</th>
                      <th className="px-5 py-2.5 text-right font-medium">Total</th>
                      <th className="px-5 py-2.5 text-right font-medium">Balance</th>
                      <th className="px-5 py-2.5 text-left font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border bg-card">
                    {previewTab === "sales" ? (
                      cleanedSales && cleanedSales.length > 0 ? (
                        cleanedSales.slice(0, 10).map((row: any, i: number) => (
                          <tr key={i} className="hover:bg-secondary/20 transition-colors">
                            <td className="px-5 py-3 font-mono text-[11px]">{row.invoice_number}</td>
                            <td className="px-5 py-3 font-semibold text-foreground">{row.party_name}</td>
                            <td className="px-5 py-3 text-muted-foreground">{row.date}</td>
                            <td className="px-5 py-3 text-right text-foreground font-medium">{formatMoney(row.total)}</td>
                            <td className="px-5 py-3 text-right text-accent-2 font-semibold">{formatMoney(row.balance)}</td>
                            <td className="px-5 py-3">
                              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ${
                                row.status === "paid" ? "bg-accent/10 text-accent-2" : "bg-yellow-500/10 text-yellow-700"
                              }`}>
                                {row.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="px-5 py-8 text-center text-muted-foreground">
                            No cleaned sales records available. Make sure fields like "Invoice Number", "Customer Name", "Total" and "Balance" exist in your upload.
                          </td>
                        </tr>
                      )
                    ) : (
                      cleanedPurchase && cleanedPurchase.length > 0 ? (
                        cleanedPurchase.slice(0, 10).map((row: any, i: number) => (
                          <tr key={i} className="hover:bg-secondary/20 transition-colors">
                            <td className="px-5 py-3 font-mono text-[11px]">{row.invoice_number}</td>
                            <td className="px-5 py-3 font-semibold text-foreground">{row.party_name}</td>
                            <td className="px-5 py-3 text-muted-foreground">{row.date}</td>
                            <td className="px-5 py-3 text-right text-foreground font-medium">{formatMoney(row.total)}</td>
                            <td className="px-5 py-3 text-right text-accent-2 font-semibold">{formatMoney(row.balance)}</td>
                            <td className="px-5 py-3">
                              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ${
                                row.status === "paid" ? "bg-accent/10 text-accent-2" : "bg-yellow-500/10 text-yellow-700"
                              }`}>
                                {row.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="px-5 py-8 text-center text-muted-foreground">
                            No cleaned purchase records available. Make sure fields like "Bill Number", "Vendor Name", "Total" and "Balance" exist in your upload.
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
              <div className="bg-secondary/40 px-5 py-3.5 text-xs text-muted-foreground border-t border-border flex justify-between font-medium">
                <span>Showing top 10 preview records</span>
                <span>Total records in memory: {previewTab === "sales" ? cleanedSales?.length : cleanedPurchase?.length}</span>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center shadow-card">
      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/10 text-accent">
        <Sparkles className="h-7 w-7" />
      </div>
      <h2 className="mt-4 text-lg font-semibold text-foreground">No live data yet</h2>
      <p className="mx-auto mt-1.5 max-w-md text-sm text-muted-foreground">
        Pull live invoice and ledger data directly from your Zoho Books organization to populate KPIs, charts and
        the live invoice table.
      </p>
      <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-secondary/60 px-3 py-1 text-[11px] text-muted-foreground">
        <Cable className="h-3 w-3" />
        Click "Sync Live Zoho Books Data" above to begin
      </div>
    </div>
  );
}

function EmptyChart({ label }: { label: string }) {
  return (
    <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">{label}</div>
  );
}

function PipelineSteps({ step, compact = false }: { step: number; compact?: boolean }) {
  return (
    <div className={`rounded-2xl border border-border bg-card shadow-card ${compact ? "p-4" : "p-6"}`}>
      {!compact && (
        <div className="mb-5">
          <h3 className="text-sm font-semibold text-foreground">Live Sync Pipeline</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Streaming from Zoho Books · OAuth 2.0</p>
        </div>
      )}
      <div className="space-y-3">
        {STEPS.map((s, i) => {
          const Icon = s.icon;
          const state: "done" | "active" | "pending" =
            i < step ? "done" : i === step ? "active" : "pending";
          return (
            <div
              key={i}
              className={`flex items-center gap-3 rounded-xl border px-4 py-3 transition-all duration-300 ${
                state === "active"
                  ? "border-accent/40 bg-accent/5"
                  : state === "done"
                    ? "border-accent/30 bg-accent/[0.03]"
                    : "border-border bg-secondary/30 opacity-60"
              }`}
            >
              <div
                className={`flex h-9 w-9 items-center justify-center rounded-lg transition-colors ${
                  state === "done"
                    ? "bg-accent text-white"
                    : state === "active"
                      ? "bg-accent/15 text-accent-2"
                      : "bg-secondary text-muted-foreground"
                }`}
              >
                {state === "done" ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : state === "active" ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Icon className="h-4 w-4" />
                )}
              </div>
              <div className="flex-1 text-sm font-medium text-foreground">{s.label}</div>
              <div className="text-[11px] font-medium uppercase tracking-wide">
                {state === "done" ? (
                  <span className="text-accent-2">Complete</span>
                ) : state === "active" ? (
                  <span className="text-accent-2">Running…</span>
                ) : (
                  <span className="text-muted-foreground">Pending</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function InvoiceTable({
  invoices,
  currency,
  onDownload,
}: {
  invoices: SyncResult["invoices"];
  currency: string;
  onDownload?: () => void;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card shadow-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Live Invoices</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Top {invoices.length} most recent from Zoho Books
          </p>
        </div>
        {onDownload && (
          <Button variant="outline" size="sm" onClick={onDownload} className="gap-2">
            <Download className="h-4 w-4" />
            Download CSV
          </Button>
        )}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-secondary/40 text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-5 py-2.5 text-left font-medium">Invoice #</th>
              <th className="px-5 py-2.5 text-left font-medium">Customer</th>
              <th className="px-5 py-2.5 text-left font-medium">Date</th>
              <th className="px-5 py-2.5 text-right font-medium">Total</th>
              <th className="px-5 py-2.5 text-right font-medium">Balance</th>
              <th className="px-5 py-2.5 text-left font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {invoices.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-5 py-8 text-center text-xs text-muted-foreground">
                  No invoices returned for this organization.
                </td>
              </tr>
            ) : (
              invoices.map((r) => (
                <tr key={r.invoice_id ?? r.invoice_number} className="transition-colors hover:bg-secondary/40">
                  <td className="px-5 py-3 font-mono text-xs text-foreground">{r.invoice_number ?? "—"}</td>
                  <td className="px-5 py-3 text-foreground">{r.customer_name ?? "—"}</td>
                  <td className="px-5 py-3 text-muted-foreground">{r.date ?? "—"}</td>
                  <td className="px-5 py-3 text-right font-medium text-foreground">
                    {typeof r.total === "number" ? formatMoney(r.total, r.currency_code ?? currency) : "—"}
                  </td>
                  <td className="px-5 py-3 text-right text-foreground">
                    {typeof r.balance === "number" ? formatMoney(r.balance, r.currency_code ?? currency) : "—"}
                  </td>
                  <td className="px-5 py-3">
                    <StatusPill status={r.status ?? "unknown"} />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const s = status.toLowerCase();
  const cls =
    s === "paid"
      ? "bg-accent/10 text-accent-2"
      : s === "overdue"
        ? "bg-destructive/10 text-destructive"
        : s === "sent" || s === "viewed" || s === "partially_paid"
          ? "bg-yellow-500/10 text-yellow-700"
          : "bg-secondary text-muted-foreground";
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium capitalize ${cls}`}>
      {status.replace(/_/g, " ")}
    </span>
  );
}

